# S4 test vectors

Data-only test vectors for the S4 paper.

- `s4_fuzz_expected.json`: expected W/E/U/F_unsound counts and Lean check outcomes.
- Source code, extractors, and execution commands are not included.
- License: CC BY 4.0.
