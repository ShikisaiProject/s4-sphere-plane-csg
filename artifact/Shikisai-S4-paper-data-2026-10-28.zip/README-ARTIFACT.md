# S4 paper and data artifact

A Fail-Safe Exact Kernel for Rational Sphere-Plane CSG with a Machine-Checked Combinatorial Boundary

- Code: not included in this record.
- Paper DOI: `10.5281/zenodo.23721477`
- Companion paper: `S5 companion record (DOI assigned on publication)`

## Contents

- `papers/`: S4 PDF and source
- `data/`: artifact data, tables, and test vectors

## License

- Paper text and artifact data: **CC BY 4.0**.
- Research code and Lean proofs are not included in this record.
- Axiom product core, MCP server, CLI, and CA keys: **not included**.

## Product boundary

The Axiom product is separate from this artifact. Its licensing is not
determined by this artifact. No proprietary A' source or signing key is included.
